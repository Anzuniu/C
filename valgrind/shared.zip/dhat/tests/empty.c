// No allocations.

int main(void)
{
   return 0;
}
